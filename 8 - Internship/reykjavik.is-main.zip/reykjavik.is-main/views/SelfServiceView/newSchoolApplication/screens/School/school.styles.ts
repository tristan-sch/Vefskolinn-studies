import styled from 'styled-components';

export const FieldRadioWrapper = styled.div`
  .FormField {
    margin-bottom: 0rem;
  }
`;
